import { Filter } from "../components/Filter"
import { EmptyPage } from "../components/Layout"
export default function Product() {
  return ( <EmptyPage>
        <Filter></Filter>
    



  </EmptyPage>
  )
}