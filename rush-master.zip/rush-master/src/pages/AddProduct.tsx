import AddProducts from "../components/AddProducts"

export default function AddProduct() {
  return  (
      <AddProducts></AddProducts>
  );
}

